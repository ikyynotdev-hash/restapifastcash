const fetch = require('node-fetch');

module.exports = function (app) {
    app.get('/download/play', async (req, res) => {
        const { apikey, query } = req.query;
        if (!apikey) return res.status(400).json({
            status: false,
            error: 'apikey is required'
        });

        if (!global.apikey.includes(apikey)) return res.status(403).json({
            status: false,
            error: 'invalid apikey'
        });

        if (!query) return res.status(400).json({
            status: false,
            error: 'query is required'
        });

        try {
            const response = await fetch(`https://api.ootaizumi.web.id/downloader/youtube-play?query=${encodeURIComponent(query)}`);
            if (!response.ok) throw new Error(`Fetch error: ${response.status}`);
            const anu = await response.json();

            if (!anu?.status || !anu.result) {
                return res.status(404).json({
                    tatus: false,
                    error: 'Lagu tidak ditemukan, coba kata kunci lain.'
                });
            }

            const result = anu.result;
            const data = {
                title: result.title,
                author: result.author?.channelTitle || '-',
                duration: result.metadata?.duration || '-',
                thumbnail: result.thumbnail,
                url: result.url,
                download: result.download
            };

            res.status(200).json({
                status: true,
                result: data
            });
        } catch (error) {
            res.status(500).json({
                status: false,
                error: error.message
            });
        }
    });
};
